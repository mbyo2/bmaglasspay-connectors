# BMaGlass Pay for Magento 2 (2.4.6–2.4.9) — install

## 1. Upload
Copy the `BMaGlass/` folder from this zip into your store's
`app/code/` directory, so the module lives at
`app/code/BMaGlass/Pay` (or install it through Magento's
Component Manager / upload path).

## 2. Install / activate
Run:
    bin/magento module:enable BMaGlass_Pay
    bin/magento setup:upgrade
    bin/magento cache:flush

## 3. Paste your API key
Go to **Stores → Configuration → Sales → Payment Methods →
BMaGlass Pay**: enable the method and paste an API key created in
your BMaGlass Pay dashboard (Business settings or the API page).
Register the webhook URL shown there in BMaGlass Pay and paste the
signing secret shown once.

## 4. Done
Customers pay on BMaGlass's hosted payment page from their BMaGlass
wallet. A live (production) API key is required at checkout; test
keys only pass connection checks. Only ZMW and USD store currencies
are supported — those are the currencies BMaGlass wallets hold.

Support: https://bmaglasspay.online/developers
