<?php
/**
 * Plugin Name:       BMaGlass Pay for WooCommerce
 * Plugin URI:        https://bmaglasspay.online/developers
 * Description:       Accept BMaGlass Pay payments in WooCommerce — buyers pay wallet-to-wallet on a hosted BMaGlass payment page, and the money lands in the same BMaGlass wallets (ZMW / USD) as your app account. Stores whose BMaGlass account has mobile money connected also get a Mobile Money gateway (MTN / Airtel / Zamtel). Built on the BMaGlass Pay developer API.
 * Version:           1.2.0
 * Author:            BMaGlass Pay
 * License:           GPL-2.0-or-later
 * Text Domain:       bmaglass-pay
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * WC requires at least: 7.0
 * WC tested up to:   11.2
 *
 * How settlement is confirmed: the developer API fires a signed
 * payment_link.paid webhook the moment a payment link is paid, and
 * this plugin's HMAC-verified endpoint completes the matching order
 * immediately (exactly once). API reconciliation (WP-Cron every 5
 * minutes + an immediate check on the thank-you page + a per-order
 * admin action) remains as the fallback for any delivery the site
 * misses — both paths are guarded so they can never double-complete.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BMAGLASS_PAY_VERSION', '1.2.0');
define('BMAGLASS_PAY_DIR', plugin_dir_path(__FILE__));

require_once BMAGLASS_PAY_DIR . 'includes/class-bmaglass-api-client.php';
require_once BMAGLASS_PAY_DIR . 'includes/class-bmaglass-reconciler.php';

/** Stored gateway settings (woocommerce_bmaglass_settings option). */
function bmaglass_settings()
{
    $s = get_option('woocommerce_bmaglass_settings', array());
    return is_array($s) ? $s : array();
}

/** Client built from saved settings, or null. */
function bmaglass_client_from_settings()
{
    $s = bmaglass_settings();
    $key = isset($s['api_key']) ? trim((string) $s['api_key']) : '';
    if ($key === '') {
        return null;
    }
    try {
        return new BMaGlassClient($key);
    } catch (BMaGlassApiException $e) {
        return null;
    }
}

// ── WooCommerce feature compatibility (HPOS + Checkout Blocks) ──────
// Declared the documented way, before WooCommerce initialises: the
// gateway and reconciler use only CRUD order APIs and order meta
// (wc_get_order / wc_get_orders / get_meta / update_meta_data), which
// is the HPOS-safe surface — no direct postmeta or wp_posts access —
// and the checkout-block integration below registers the gateway for
// the Cart/Checkout blocks (the default checkout since WC 10.6).
add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

// ── Checkout Blocks integration ─────────────────────────────────────
// Registers the gateway as a Blocks payment method type; without
// this the gateway is invisible in the block checkout. The block
// collects no fields — WooCommerce routes the submission to the
// gateway's classic process_payment() server-side.
add_action('woocommerce_blocks_payment_method_type_registration', function ($registry) {
    if (!class_exists('Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType')) {
        return;
    }
    require_once BMAGLASS_PAY_DIR . 'includes/class-bmaglass-blocks-integration.php';
    $registry->register(new BMaGlass_Blocks_Integration());
    require_once BMAGLASS_PAY_DIR . 'includes/class-bmaglass-momo-blocks-integration.php';
    $registry->register(new BMaGlass_Momo_Blocks_Integration());
});

add_action('init', function () {
    wp_register_script(
        'bmaglass-blocks-integration',
        plugins_url('assets/js/blocks-integration.js', __FILE__),
        array('wc-blocks-registry', 'wc-settings', 'wp-element'),
        BMAGLASS_PAY_VERSION,
        true
    );
    wp_register_script(
        'bmaglass-momo-blocks-integration',
        plugins_url('assets/js/momo-blocks-integration.js', __FILE__),
        array('wc-blocks-registry', 'wc-settings', 'wp-element'),
        BMAGLASS_PAY_VERSION,
        true
    );
});

// ── Gateway registration ─────────────────────────────────────────────
add_filter('woocommerce_payment_gateways', function ($gateways) {
    $gateways[] = 'WC_Gateway_BMaGlass';
    $gateways[] = 'WC_Gateway_BMaGlass_Mobile_Money';
    return $gateways;
});

add_action('plugins_loaded', function () {
    if (!class_exists('WC_Payment_Gateway')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>BMaGlass Pay:</strong> WooCommerce is not active, so the BMaGlass Pay gateway can\'t run. Activate WooCommerce first.</p></div>';
        });
        return;
    }
    require_once BMAGLASS_PAY_DIR . 'includes/class-wc-gateway-bmaglass.php';
    require_once BMAGLASS_PAY_DIR . 'includes/class-wc-gateway-bmaglass-momo.php';
});

// ── Reconciliation cron (every 5 minutes) ────────────────────────────
add_filter('cron_schedules', function ($schedules) {
    $schedules['bmaglass_5min'] = array('interval' => 300, 'display' => 'Every 5 minutes (BMaGlass)');
    return $schedules;
});

register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('bmaglass_reconcile_orders')) {
        wp_schedule_event(time() + 300, 'bmaglass_5min', 'bmaglass_reconcile_orders');
    }
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('bmaglass_reconcile_orders');
});

add_action('bmaglass_reconcile_orders', array('BMaGlass_Reconciler', 'reconcile_pending'));

// Immediate check when the buyer lands back on the thank-you page.
add_action('woocommerce_thankyou', function ($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }
    $client = bmaglass_client_from_settings();
    if ($client === null) {
        return;
    }
    if ($order->get_payment_method() === 'bmaglass') {
        BMaGlass_Reconciler::reconcile_order($order, $client);
    } elseif ($order->get_payment_method() === 'bmaglass_momo') {
        BMaGlass_Reconciler::reconcile_momo_order($order, $client);
    }
}, 20);

// Per-order admin action: "Check BMaGlass payment".
add_filter('woocommerce_order_actions', function ($actions, $order) {
    if ($order && $order->get_payment_method() === 'bmaglass' && $order->get_meta('_bmaglass_link_code')) {
        $actions['bmaglass_check_payment'] = 'Check BMaGlass payment';
    }
    if ($order && $order->get_payment_method() === 'bmaglass_momo' && $order->get_meta('_bmaglass_momo_reference')) {
        $actions['bmaglass_check_momo_payment'] = 'Check mobile money payment';
    }
    return $actions;
}, 10, 2);

add_action('woocommerce_order_action_bmaglass_check_momo_payment', function ($order) {
    $client = bmaglass_client_from_settings();
    if ($client === null) {
        $order->add_order_note('BMaGlass: no API key configured — settlement check skipped.');
        return;
    }
    if (!BMaGlass_Reconciler::reconcile_momo_order($order, $client)) {
        $order->add_order_note('BMaGlass mobile money: checked just now — the collection hasn\'t settled yet.');
    }
});

add_action('woocommerce_order_action_bmaglass_check_payment', function ($order) {
    $client = bmaglass_client_from_settings();
    if ($client === null) {
        $order->add_order_note('BMaGlass: no API key configured — settlement check skipped.');
        return;
    }
    if (!BMaGlass_Reconciler::reconcile_order($order, $client)) {
        $order->add_order_note('BMaGlass: checked just now — no completed payment for this order\'s link yet.');
    }
});

// ── Webhook endpoint (HMAC-verified) ─────────────────────────────────
add_action('rest_api_init', function () {
    register_rest_route('bmaglass/v1', '/webhook', array(
        'methods' => 'POST',
        // Public by necessity (BMaGlass servers call it); security is
        // the HMAC signature check against the stored webhook secret.
        'permission_callback' => '__return_true',
        'callback' => 'bmaglass_handle_webhook',
    ));
});

function bmaglass_handle_webhook(WP_REST_Request $request)
{
    $s = bmaglass_settings();
    $secret = isset($s['webhook_secret']) ? (string) $s['webhook_secret'] : '';
    $raw = $request->get_body();
    $signature = $request->get_header('x-bmaglass-signature');

    if ($secret === '' || !BMaGlassClient::verifyWebhookSignature($raw, $signature, $secret)) {
        return new WP_REST_Response(array('error' => 'invalid_signature'), 401);
    }
    $event = json_decode($raw, true);
    if (!is_array($event) || !isset($event['type'])) {
        return new WP_REST_Response(array('error' => 'invalid_payload'), 400);
    }

    $logger = wc_get_logger();
    $type = (string) $event['type'];
    switch ($type) {
        case 'webhook.test':
            // Connectivity proof sent from the settings screen / API.
            $logger->info('BMaGlass webhook.test received and verified.', array('source' => 'bmaglass-pay'));
            break;
        case 'payment_link.created':
            $logger->info('BMaGlass payment_link.created: ' . wp_json_encode(isset($event['data']) ? $event['data'] : array()), array('source' => 'bmaglass-pay'));
            break;
        case 'payment_link.paid':
            // The settlement event: complete the matching order now.
            // The reconciler cross-checks link code, currency and
            // amount, and completes exactly once; if its checks
            // decline the payload, fall back to API reconciliation
            // for that order before giving up.
            $paidData = isset($event['data']) && is_array($event['data']) ? $event['data'] : array();
            $paidCode = isset($paidData['link_code']) ? (string) $paidData['link_code'] : '';
            $paidSettled = false;
            if ($paidCode !== '') {
                $paidSettled = BMaGlass_Reconciler::complete_order_from_event(
                    $paidCode,
                    isset($paidData['amount']) ? $paidData['amount'] : 0,
                    isset($paidData['currency']) ? $paidData['currency'] : ''
                );
                if (!$paidSettled) {
                    $paidOrder = BMaGlass_Reconciler::find_order_by_link_code($paidCode);
                    $paidClient = bmaglass_client_from_settings();
                    if ($paidOrder && $paidClient !== null) {
                        $paidSettled = BMaGlass_Reconciler::reconcile_order($paidOrder, $paidClient);
                    }
                }
            }
            $logger->info(
                'BMaGlass payment_link.paid: link ' . $paidCode . ($paidSettled ? ' — order settled.' : ' — no unsettled order matched (already settled or unknown link).'),
                array('source' => 'bmaglass-pay')
            );
            break;
        case 'mobile_money.collection.completed':
            // A mobile-money collection started at checkout settled:
            // complete the matching order now (cross-checked against
            // the order's amount/currency), with API reconciliation
            // as the fallback for that order.
            $momoData = isset($event['data']) && is_array($event['data']) ? $event['data'] : array();
            $momoRef = isset($momoData['merchant_reference']) ? (string) $momoData['merchant_reference'] : '';
            $momoSettled = false;
            if ($momoRef !== '') {
                $momoSettled = BMaGlass_Reconciler::complete_momo_order_from_event(
                    $momoRef,
                    isset($momoData['amount']) ? $momoData['amount'] : 0,
                    isset($momoData['currency']) ? $momoData['currency'] : ''
                );
                if (!$momoSettled) {
                    $momoOrder = BMaGlass_Reconciler::find_order_by_momo_merchant_reference($momoRef);
                    $momoClient = bmaglass_client_from_settings();
                    if ($momoOrder && $momoClient !== null) {
                        $momoSettled = BMaGlass_Reconciler::reconcile_momo_order($momoOrder, $momoClient);
                    }
                }
            }
            $logger->info(
                'BMaGlass mobile_money.collection.completed: ' . $momoRef . ($momoSettled ? ' — order settled.' : ' — no unsettled order matched (already settled or unknown reference).'),
                array('source' => 'bmaglass-pay')
            );
            break;
        case 'transaction.completed':
            // Fires for the merchant account's own API transfers. Its
            // payload (transaction_id/amount/currency) carries no
            // order identity, so it cannot complete a WooCommerce
            // order — checkout settlement is confirmed by the
            // reconciler. Logged here for a complete signed audit trail.
            $logger->info('BMaGlass transaction.completed: ' . wp_json_encode(isset($event['data']) ? $event['data'] : array()), array('source' => 'bmaglass-pay'));
            break;
        default:
            $logger->info('BMaGlass webhook event (unhandled type): ' . $type, array('source' => 'bmaglass-pay'));
    }
    return new WP_REST_Response(array('received' => true), 200);
}

// ── Settings-screen actions: Test connection / Register webhook ──────
function bmaglass_admin_redirect($notice, $type = 'success')
{
    $url = admin_url('admin.php?page=wc-settings&tab=checkout&section=bmaglass');
    set_transient('bmaglass_admin_notice_' . get_current_user_id(), array($notice, $type), 60);
    wp_safe_redirect($url);
    exit;
}

add_action('admin_notices', function () {
    $t = get_transient('bmaglass_admin_notice_' . get_current_user_id());
    if ($t) {
        delete_transient('bmaglass_admin_notice_' . get_current_user_id());
        printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
            $t[1] === 'error' ? 'error' : 'success', esc_html($t[0]));
    }
});

add_action('admin_post_bmaglass_test_connection', function () {
    check_admin_referer('bmaglass_test_connection');
    if (!current_user_can('manage_woocommerce')) {
        wp_die('Not allowed.');
    }
    $client = bmaglass_client_from_settings();
    if ($client === null) {
        bmaglass_admin_redirect('Save a BMaGlass API key first, then test the connection.', 'error');
    }
    try {
        $wallets = $client->wallets();
        $parts = array();
        foreach ((array) $wallets as $w) {
            $parts[] = sprintf('%s %s', $w['currency'], number_format((float) $w['balance'], 2));
        }
        $environment = $client->environment();
        $msg = sprintf('Connected to BMaGlass Pay (%s). Wallets: %s.', ucfirst($environment), implode(' · ', $parts));
        // Render the connector configuration the key unlocked: the
        // business's country and its feature states come from the
        // account, never from a plugin setting.
        try {
            $config = $client->connectorConfig();
            $country = isset($config['business']['country']) ? $config['business']['country'] : null;
            if ($country) {
                $msg .= sprintf(' Business country: %s.', $country);
            }
            $mm = isset($config['features']['mobile_money']['status']) ? $config['features']['mobile_money']['status'] : null;
            if ($mm === 'enabled') {
                $msg .= ' Mobile money: on.';
            } elseif ($mm === 'not_entitled') {
                $msg .= ' Mobile money: available to businesses registered in Zambia.';
            } elseif ($mm === 'disabled') {
                $msg .= ' Mobile money: off — switch it on in your BMaGlass business settings.';
            }
        } catch (BMaGlassApiException $e) {
            // The wallet read already proved the connection; config is
            // presentation on top — never fail the check on it.
        }
        if ($environment === 'sandbox') {
            $msg .= ' This is a SANDBOX key: connection and reads work and payments can be simulated, but checkout can\'t take real payments with it. Switch to a production key to sell.';
        }
        bmaglass_admin_redirect($msg);
    } catch (BMaGlassApiException $e) {
        bmaglass_admin_redirect($e->userMessage(), 'error');
    }
});

add_action('admin_post_bmaglass_register_webhook', function () {
    check_admin_referer('bmaglass_register_webhook');
    if (!current_user_can('manage_woocommerce')) {
        wp_die('Not allowed.');
    }
    $client = bmaglass_client_from_settings();
    if ($client === null) {
        bmaglass_admin_redirect('Save a BMaGlass API key first, then register the webhook.', 'error');
    }
    try {
        $s = bmaglass_settings();
        // Retire any previous registration first: re-registering (e.g. after a
        // site migration) must not leave the old webhook active on the account,
        // or every event would be delivered to the stale URL as well.
        if (!empty($s['webhook_id'])) {
            try {
                $client->deleteWebhook($s['webhook_id']);
            } catch (BMaGlassApiException $e) {
                // Best-effort cleanup; never block the new registration on it.
            }
        }
        $hook = $client->createWebhook(
            rest_url('bmaglass/v1/webhook'),
            array('transaction.completed', 'payment_link.created', 'payment_link.paid', 'mobile_money.collection.completed', 'webhook.test')
        );
        $s['webhook_id'] = isset($hook['id']) ? $hook['id'] : '';
        if (!empty($hook['secret'])) {
            // The secret is returned exactly once — store it now.
            $s['webhook_secret'] = $hook['secret'];
        }
        update_option('woocommerce_bmaglass_settings', $s);
        // Fire the signed test event so the merchant sees a verified delivery.
        if (!empty($s['webhook_id'])) {
            try {
                $client->testWebhook($s['webhook_id']);
            } catch (BMaGlassApiException $e) {
                // Registration still succeeded; the test send is a bonus.
            }
        }
        bmaglass_admin_redirect('Webhook registered with BMaGlass Pay and a signed test event was sent to this site. Check WooCommerce → Status → Logs (source: bmaglass-pay) to see it arrive.');
    } catch (BMaGlassApiException $e) {
        bmaglass_admin_redirect($e->userMessage(), 'error');
    }
});
