# BMaGlass Pay for OpenCart 3 — install

## 1. Upload
In your admin panel, go to **Extensions → Installer** and upload
this zip (or copy the contents of the `upload/` folder over your
OpenCart root manually).

## 2. Install / activate
Go to **Extensions → Extensions → Payments → BMaGlass Pay** and
click **Install**, then **Edit**.

## 3. Paste your API key
Enable the payment method and paste an API key created in your
BMaGlass Pay dashboard (Business settings or the API page). Use
**Test connection** to check the key, register the webhook URL
shown in BMaGlass Pay, paste the signing secret shown once, and
pick the order status for paid orders.

## 4. Done
Customers pay on BMaGlass's hosted payment page from their BMaGlass
wallet. A live (production) API key is required to take payments;
test keys only pass the connection check. Only ZMW and USD store
currencies are supported — those are the currencies BMaGlass
wallets hold.

Support: https://bmaglasspay.online/developers
