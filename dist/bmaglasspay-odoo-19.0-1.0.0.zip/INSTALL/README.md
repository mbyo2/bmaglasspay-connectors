# BMaGlass Pay for Odoo 19.0 — install

## 1. Upload
In Odoo, go to **Apps → Import Module** and upload this zip
(or copy the `payment_bmaglass/` folder into your Odoo addons path
and update the apps list).

## 2. Install / activate
Install **Payment Provider: BMaGlass Pay** from the Apps list.

## 3. Paste your API key
Go to **Invoicing / Accounting → Configuration → Payment Providers →
BMaGlass Pay** and paste an API key created in your BMaGlass Pay
dashboard (Business settings or the API page).

Use **Test connection** to check the key, then **Register webhook**
so BMaGlass can confirm payments to your store.

## 4. Done
Customers pay on BMaGlass's hosted payment page from their BMaGlass
wallet. A live (production) API key is required to take payments;
test keys only pass the connection check. Only ZMW and USD orders
are supported — those are the currencies BMaGlass wallets hold.

Support: https://bmaglasspay.online/developers
