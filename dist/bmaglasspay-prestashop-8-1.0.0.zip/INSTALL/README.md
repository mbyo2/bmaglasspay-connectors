# BMaGlass Pay for PrestaShop 8 — install

## 1. Upload
In your back office, go to **Module Manager → Upload a module**
and select this zip (or copy the `bmaglasspay/` folder into
your store's `modules/` directory).

## 2. Install / activate
Install **BMaGlass Pay** from the module list and open its
configuration page.

## 3. Paste your API key
Paste an API key created in your BMaGlass Pay dashboard (Business
settings or the API page). Register the webhook URL shown on the
configuration page in BMaGlass Pay and paste the signing secret
shown once. Use **Test connection** to check the key.

## 4. Done
Customers pay on BMaGlass's hosted payment page from their BMaGlass
wallet. A live (production) API key is required at checkout; test
keys only pass the connection check. Only ZMW and USD store
currencies are supported — those are the currencies BMaGlass
wallets hold.

Support: https://bmaglasspay.online/developers
